@extends('layouts.backoffice.master')
@section('cuerpobackoffice')
<div class="panel panel-danger"  data-sortable-id="ui-widget-3">
    <div class="panel-heading ui-sortable-handle">
        <div class="btn-group btn-group-toggle pull-right">
            <a href="javascript:;" class="btn btn-warning" onclick="modal({route:'venta/create?view=registrar',size:'modal-fullscreen'})"><i class="fa fa-plus"></i> Registrar</a>
        </div>
        <h4 class="panel-title">Ventas</h4>
    </div>
    <div class="panel-body">
        <div class="row">
            <div class="col-md-4"> 
            </div>
            <div class="col-md-4"> 
                <input class="form-control" type="text" id="codigoventamaster" placeholder="Código de Cotización" style="height: 40px;font-size: 16px;text-align: center;"/>
            </div>
        </div>
        <div class="table-responsive">
        <table class="table table-bordered table-hover table-striped" id="tabla-contenido">
            <thead class="thead-dark">
              <tr>
                <th width="110px">Código</th>
                <th width="120px">Fecha de registro</th>
                <th width="100px">Vendedor</th>
                <th>Cliente</th>
                <th width="100px">Total</th>
                <th width="100px">Total Pagado</th>
                <th width="100px">Total Deuda</th>
                <th width="10px">Pago</th>
                <th width="10px">Comprobantes</th>
                <th width="10px">Estado</th>
                <th width="10px"></th>
              </tr>
            </thead>
            @include('app.tablesearch',[
                'searchs'=>['codigo','date:fecharegistro','vendedor','cliente','','','','','','',''],
                'search_url'=> url('backoffice/venta')
            ])
            <tbody>
                @foreach($ventas as $value)
                <?php 
                  /**Validar Anulacion */
                  $cobranzacredito_exist = DB::table('cobranzacredito')
                    ->where('idventa', $value->id)
                    ->exists();
                  $cobranzaletra_exist   = DB::table('tipopagoletra')
                    ->join('venta', 'venta.id', 'tipopagoletra.idventa')
                    ->join('cobranzaletra', 'cobranzaletra.idtipopagoletra', 'tipopagoletra.id')
                    ->where('tipopagoletra.idventa', $value->id)->exists();
                  $notadevolucion_exist = DB::table('notadevolucion')->where('idventa', $value->id)->exists();
                  /**Fin Validar Anulacion */
              
                  $totalnotadevolucion = DB::table('notadevolucion')
                    ->where('notadevolucion.idestado',2)
                    ->where('notadevolucion.idventa',$value->id)
                    ->sum('total');
              
                  $totalapagado = DB::table('notadevoluciondetalle')
                          ->join('notadevolucion','notadevolucion.id','notadevoluciondetalle.idnotadevolucion')
                          ->where('notadevolucion.idestado',2)
                          ->where('notadevolucion.idventa',$value->id)
                          ->sum(DB::raw('CONCAT(notadevoluciondetalle.cantidad*notadevoluciondetalle.preciounitario)'));
              
                  $totalpagado = 0;
                  $deudatotal = 0;
                  if($value->idformapago==1){
                      $totalpagado = $value->montorecibido-$totalapagado;
                  }elseif($value->idformapago==2){
                      $totalpagado = DB::table('cobranzacredito')
                          ->where('idestado',2)
                          ->where('idventa',$value->id)
                          ->sum('monto');
                      $deudatotal = $value->montorecibido-$totalpagado-$totalapagado+$totalnotadevolucion;
                      $totalpagado = $totalpagado-$totalnotadevolucion;
                  }elseif($value->idformapago==3){
                      $totalpagado = DB::table('cobranzaletra')
                          ->join('tipopagoletra','tipopagoletra.id','cobranzaletra.idtipopagoletra')
                          ->where('cobranzaletra.idestado',2)
                          ->where('tipopagoletra.idventa',$value->id)
                          ->sum('cobranzaletra.monto');
                      $deudatotal = $value->montorecibido-$totalpagado-$totalnotadevolucion;
                  }
                  // fin Total pagado
              
                  $guairemision = DB::table('facturacionguiaremision')->where('facturacionguiaremision.idventa', $value->id)->first();
                  
                  $facturacionboletafacturas = DB::table('facturacionboletafactura')
                      ->join('facturacionboletafacturadetalle','facturacionboletafacturadetalle.idfacturacionboletafactura','facturacionboletafactura.id')
                      ->where('facturacionboletafactura.idventa',$value->id)
                      ->orWhere('facturacionboletafacturadetalle.idventa',$value->id)
                      ->select(
                          'facturacionboletafactura.venta_serie as venta_serie',
                          'facturacionboletafactura.venta_correlativo as venta_correlativo'
                      )
                      ->orderBy('facturacionboletafactura.id','desc')
                      ->distinct()
                      ->get();
                  ?>
                <tr>
                  <td>{{ str_pad($value->codigo, 8, "0", STR_PAD_LEFT) }}</td>
                  <td>{{ $value->fechaconfirmacion }}</td>
                  <td>{{ $value->nombreusuariovendedor }}</td>
                  <td>{{ $value->cliente }}</td>
                  <td>
                    {{ $value->monedasimbolo }} {{ $value->montorecibido }}
                  </td>
                  <td <?php echo $deudatotal>0?'style="background-color: #ef7d88;color: #352828;"':'style="background-color: #76e08f;color: #352828;"'?>>
                    {{ $value->monedasimbolo }} {{ number_format($totalpagado, 2, '.', '') }}
                  </td>
                  <td <?php echo $deudatotal>0?'style="background-color: #ef7d88;color: #352828;"':'style="background-color: #76e08f;color: #352828;"'?>>
                    {{ $value->monedasimbolo }} {{ number_format($deudatotal, 2, '.', '') }}
                  </td>
                  <td>{{ $value->nombreFormapago }}</td>
                  <td>
                    @foreach($facturacionboletafacturas as $valuefacturas)
                    <span class="badge badge-pill badge-warning">{{ $valuefacturas->venta_serie }}-{{ $valuefacturas->venta_correlativo }}</span>
                    @endforeach
                  </td>
                  <td>
                    @if($value->idestado==2)
                        <div class="td-badge"><span class="badge badge-pill badge-info"><i class="fa fa-sync-alt"></i> Pendiente</span></div> 
                    @elseif($value->idestado==3)
                        <div class="td-badge"><span class="badge badge-pill badge-success"><i class="fa fa-check"></i> Confirmado</span></div>
                    @elseif($value->idestado==4)
                        <div class="td-badge"><span class="badge badge-pill badge-dark"><i class="fa fa-ban"></i> Anulado</span></div>
                    @endif  
                  </td>
                  <td class="with-btn-group" nowrap>
                    <div class="btn-group">
                      <a href="#" class="btn btn-white btn-sm dropdown-toggle width-80 no-caret" data-toggle="dropdown">
                        Opción <span class="caret"></span>
                      </a>
                      <ul class="dropdown-menu pull-right">
                         @if($value->idestado==2)
                         <li><a href="javascript:;" onclick="modal({route:'venta/{{ $value->id }}/edit?view=editar',size:'modal-fullscreen'})">
                            <i class="fa fa-edit"></i> Editar
                         </a></li>
                         <li><a href="javascript:;" onclick="modal({route:'venta/{{ $value->id }}/edit?view=proforma',size:'modal-fullscreen'})">
                            <i class="fa fa-file-alt"></i> PDF Proforma
                         </a></li>
                         <li><a href="javascript:;" onclick="modal({route:'venta/{{ $value->id }}/edit?view=correo'})">
                            <i class="fa fa-share-square"></i> Enviar Correo
                         </a></li>
                         @elseif($value->idestado==3)
                         <li><a href="javascript:;" onclick="modal({route:'venta/{{ $value->id }}/edit?view=editar',size:'modal-fullscreen'})">
                           <i class="fa fa-check-square"></i> Facturar</a></li>
                            @if (is_null($guairemision)) 
<!--                               <li><a href="javascript:;" onclick="modal({route:'facturacionguiaremision/create?view=registrar&codigoventa={{ $value->codigo }}',size:'modal-fullscreen'})">
                              <i class="fa fa-envelope"></i> Guia Remisión</a></li> -->
                           @else
<!--                              <li><a href="{{ url('backoffice/facturacionguiaremision') }}"><i class="fa fa-info-circle"></i> Guia {{ $guairemision->guiaremision_serie }} - {{ $guairemision->guiaremision_correlativo }}</a></li> -->
                            @endif
                         <li><a href="javascript:;" onclick="modal({route:'venta/{{ $value->id }}/edit?view=detalle',size:'modal-fullscreen'})">
                           <i class="fa fa-list-alt"></i> Detalle</a></li>
<!--                         <li><a href="javascript:;" onclick="modal({route:'venta/{{ $value->id }}/edit?view=reducirmonto',size:'modal-fullscreen'})">
                           <i class="far fa-credit-card"></i> Reducir Monto Total</a></li> -->
                         <li><a href="javascript:;" onclick="modal({route:'venta/{{ $value->id }}/edit?view=proforma',size:'modal-fullscreen'})">
                            <i class="fa fa-file-alt"></i> PDF Proforma
                         </a></li>
                         <li><a href="javascript:;" onclick="modal({route:'venta/{{ $value->id }}/edit?view=correo'})">
                            <i class="fa fa-share-square"></i> Enviar Correo
                         </a></li>
                         @if(count($facturacionboletafacturas) == 0 && $cobranzacredito_exist && $cobranzaletra_exist && $notadevolucion_exist) 
                         <li><a href="javascript:;" onclick="modal({route:'venta/{{ $value->id }}/edit?view=anular',size:'modal-fullscreen'})">
                            <i class="fa fa-ban"></i> Anular
                         </a></li>
                         @endif 
                         @elseif($value->idestado==4)
                         <li><a href="javascript:;" onclick="modal({route:'venta/{{ $value->id }}/edit?view=detalle',size:'modal-fullscreen'})">
                           <i class="fa fa-list-alt"></i> Detalle</a></li>
                         @endif 
                      </ul>
                    </div>
                  </td>
                </tr>
                @endforeach
            </tbody>
        </table>
        {{ $ventas->links('app.tablepagination', ['results' => $ventas]) }}
        </div>
    </div>

</div>
@endsection
@section('subscripts')
<script>
$('#codigoventamaster').keyup(function(e) {
    var code = (e.keyCode ? e.keyCode : e.which);
    if(code==13){
        modal({route:'venta/create?view=registrar&codigoventa='+$('#codigoventamaster').val(),size:'modal-fullscreen'});
    }     
});
</script>
@endsection