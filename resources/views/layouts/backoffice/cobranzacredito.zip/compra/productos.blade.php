@include('layouts/backoffice/producto/productos')
<script>
function seleccionarproducto(idproducto){
    $.ajax({
        url:"{{url('backoffice/compra/show-seleccionarproducto')}}",
        type:'GET',
        data: {
            idproducto : idproducto
        },
        success: function (respuesta){
          if(respuesta["datosProducto"]!=null){
            var validexist = 0;
            $("#tabla-compra tbody tr").each(function() {
                var num = $(this).attr('id');        
                var idproducto = $(this).attr('idproducto');
                if(idproducto==respuesta["datosProducto"].id){
                    validexist = 1;
                    alert('Ya existe en la lista!');
                }
            });
            if(validexist==0){
                agregarproducto(
                  respuesta["datosProducto"].id,
                  (respuesta["datosProducto"].codigoimpresion).padStart(6,"0"),
                  respuesta["datosProducto"].compatibilidadnombre,
                  respuesta["datosProducto"].compatibilidadmotor,
                  respuesta["datosProducto"].compatibilidadmarca,
                  respuesta["datosProducto"].compatibilidadmodelo,
                  '0.00',
                  respuesta["datosProducto"].idunidadmedida,
                  respuesta["datosProducto"].unidadmedidanombre,
                  '0',
                  '0.00'
                );
            } 
                
          }
        }
    })
}
</script>